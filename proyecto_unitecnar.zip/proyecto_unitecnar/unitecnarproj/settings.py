
SECRET_KEY='dummy'
DEBUG=True
ROOT_URLCONF='unitecnarproj.urls'
ALLOWED_HOSTS=[]
INSTALLED_APPS=['mainapp']
MIDDLEWARE=[]
TEMPLATES=[{
 'BACKEND':'django.template.backends.django.DjangoTemplates',
 'DIRS':[],
 'APP_DIRS':True,
 'OPTIONS':{},
}]
